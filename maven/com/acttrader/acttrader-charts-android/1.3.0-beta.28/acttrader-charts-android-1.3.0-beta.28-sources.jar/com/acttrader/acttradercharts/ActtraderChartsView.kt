package com.acttrader.acttradercharts

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout

/**
 * A self-contained chart view that renders `acttrader-charts` inside a [WebView].
 *
 * ## Basic usage
 * ```kotlin
 * val chart = ActtraderChartsView(context)
 * chart.onReady = { chart.loadData(bars) }
 * chart.onError = { err -> Log.e("Chart", err.message) }
 * parentLayout.addView(chart)
 * ```
 *
 * All public command methods are safe to call from any thread.
 */
class ActtraderChartsView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : FrameLayout(context, attrs, defStyleAttr) {

    // ── WebView setup ─────────────────────────────────────────────────────────

    private val mainHandler = Handler(Looper.getMainLooper())

    @SuppressLint("SetJavaScriptEnabled")
    private val webView = WebView(context).also { wv ->
        wv.layoutParams = LayoutParams(
            LayoutParams.MATCH_PARENT,
            LayoutParams.MATCH_PARENT,
        )
        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            allowFileAccess = true
        }
        wv.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        wv.setBackgroundColor(Color.parseColor("#141d22"))
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            wv.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, true)
        }
        wv.webViewClient = WebViewClient()
        addView(wv)
    }

    // Loading skeleton — shown until the `ready` event fires to eliminate the blank-flash
    // on WebView cold-start. Background matches the dark theme canvas colour.
    private val skeletonView = View(context).also { v ->
        v.layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
        v.setBackgroundColor(Color.parseColor("#13151a"))
        addView(v)
    }

    private val bridgeInterface = ChartBridgeInterface(mainHandler, null).also { iface ->
        webView.addJavascriptInterface(iface, "ChartAndroidBridge")
        iface.onBridgeEvent = { event -> dispatchEvent(event) }
    }

    // ── Command queue ─────────────────────────────────────────────────────────

    @Volatile private var isReady = false
    @Volatile private var hasCalledOnReady = false
    @Volatile private var userInitCalled = false
    @Volatile private var currentTheme: String = "dark"
    private val commandQueue = ArrayList<String>()  // guarded by synchronized(this)

    init {
        webView.loadUrl("file:///android_asset/chart.html")
    }

    /**
     * Re-colors the native WebView, skeleton, and FrameLayout to match the chart theme.
     * Prevents a visible dark seam around the canvas on light theme, and the initial
     * dark flash on cold-start when the consumer requested a light chart.
     */
    private fun applyNativeTheme(theme: String) {
        currentTheme = theme
        val canvasBg = if (theme == "light") Color.WHITE else Color.parseColor("#141d22")
        val skeletonBg = if (theme == "light") Color.WHITE else Color.parseColor("#13151a")
        webView.post {
            webView.setBackgroundColor(canvasBg)
            skeletonView.setBackgroundColor(skeletonBg)
            this@ActtraderChartsView.setBackgroundColor(canvasBg)
        }
    }

    // ── Typed event callbacks (set by the consumer) ───────────────────────────

    /** Called when the chart engine is ready to receive commands. */
    var onReady: (() -> Unit)? = null

    /** Called whenever the crosshair moves over a bar. */
    var onCrosshair: ((BridgeEvent.Crosshair) -> Unit)? = null

    /** Called when the user taps a bar. */
    var onBarClick: ((BridgeEvent.BarClick) -> Unit)? = null

    /** Called when the visible viewport changes (pan / zoom). */
    var onViewportChange: ((BridgeEvent.ViewportChange) -> Unit)? = null

    /** Called when the active series type changes. */
    var onSeriesChange: ((BridgeEvent.SeriesChange) -> Unit)? = null

    /** User picked a price source (BID / ASK / LTP) from the header dropdown
     *  (`priceSourceSelector`) — persist it host-side if desired. */
    var onPriceSourceChange: ((BridgeEvent.PriceSourceChange) -> Unit)? = null

    /** Called when the active timeframe changes. */
    var onTimeframeChange: ((BridgeEvent.TimeframeChange) -> Unit)? = null

    /** Called when the active duration changes. */
    var onDurationChange: ((BridgeEvent.DurationChange) -> Unit)? = null

    /** Called on any chart state mutation. */
    var onStateChange: ((BridgeEvent.StateChange) -> Unit)? = null

    /** Called in response to [getState]; contains the full serialised state JSON. */
    var onStateSnapshot: ((BridgeEvent.StateSnapshot) -> Unit)? = null

    /**
     * Called with the native-UI catalog once after every [init] (and on [getCatalog]).
     * Save `event.catalogJson` keyed by `event.catalogVersion` and build the native header,
     * tools and settings screens from it — entries with `"available": false` are planned
     * features you can hide.
     */
    var onCatalog: ((BridgeEvent.Catalog) -> Unit)? = null

    /** Called after [loadData] completes. */
    var onDataLoaded: ((BridgeEvent.DataLoaded) -> Unit)? = null

    /** Called when a new bar is appended at the live edge. */
    var onNewBar: ((BridgeEvent.NewBar) -> Unit)? = null

    /** Called when the stream connection status changes. */
    var onStreamStatus: ((BridgeEvent.StreamStatus) -> Unit)? = null

    /** Called when the user submits an order via the floating trade button. */
    var onPlaceOrder: ((BridgeEvent.PlaceOrder) -> Unit)? = null

    /** Called when the user taps × to close or cancel a trade level or remove a bracket. */
    var onTradeLevelClose: ((BridgeEvent.TradeLevelClose) -> Unit)? = null

    /** Called on every pointer move while a level or bracket is being dragged. */
    var onTradeLevelDrag: ((BridgeEvent.TradeLevelDrag) -> Unit)? = null

    /** Called when the user confirms edits to a trade level (main, SL, TP batched together). */
    var onTradeLevelEdit: ((BridgeEvent.TradeLevelEdit) -> Unit)? = null

    /**
     * Called on every live qty edit via the QTY pill flyout — before the level edit is confirmed.
     * Use to refresh Estimated PNL for SL/TP brackets in real time.
     */
    var onTradeLevelQtyChange: ((BridgeEvent.TradeLevelQtyChange) -> Unit)? = null

    /** Called when the chart ✓ button confirms an edit (including draft orders). */
    var onTradeLevelConfirmed: ((BridgeEvent.TradeLevelConfirmed) -> Unit)? = null

    /** Called when an in-progress level edit is cancelled from the chart (ESC key or inline ✕ cancel button). */
    var onTradeLevelEditCancelled: ((BridgeEvent.TradeLevelEditCancelled) -> Unit)? = null

    /** Called when the user taps the pencil/edit button to open the order panel for a level. */
    var onTradeLevelEditOpen: ((BridgeEvent.TradeLevelEditOpen) -> Unit)? = null

    /**
     * Called after [addLevelBracket] auto-places a SL/TP bracket.
     * Use [BridgeEvent.TradeLevelBracketActivated.price] to populate your form's SL/TP input field.
     */
    var onTradeLevelBracketActivated: ((BridgeEvent.TradeLevelBracketActivated) -> Unit)? = null

    /** Called when a new draft order is shown on the chart — open the buy/sell form. */
    var onDraftInitiated: ((BridgeEvent.DraftInitiated) -> Unit)? = null

    /** Called when a draft order is cancelled without confirming. */
    var onDraftCancelled: ((BridgeEvent.DraftCancelled) -> Unit)? = null

    /** Called when TFC (Trade from Charts) is toggled on or off via the top bar button or API. */
    var onTfcToggle: ((BridgeEvent.TfcToggle) -> Unit)? = null

    /**
     * Called when the crosshair is switched on or off — via the header switch
     * (`enableCrossHairHeader` in [init]) or [setCrosshairEnabled]. Persist `enabled` and
     * seed it back through `crosshairEnabled` on the next [init].
     */
    var onCrosshairToggle: ((BridgeEvent.CrosshairToggle) -> Unit)? = null

    /** Called when a horizontal (time-axis) badge drag starts (requires `orderLineTimeDrag`). */
    var onOrderLineMoveStart: ((BridgeEvent.OrderLineMoveStart) -> Unit)? = null

    /** Called on every move of a horizontal badge drag, before release. */
    var onOrderLineMoving: ((BridgeEvent.OrderLineMoving) -> Unit)? = null

    /**
     * Called once when a horizontal badge drag ends on a different candle. The price is
     * unchanged — only the level's time anchor moved. Persist `toTimestamp` and echo it as the
     * level's `"timestamp"` in your next [setLevels] if you keep anchors server-side.
     */
    var onOrderLineMoved: ((BridgeEvent.OrderLineMoved) -> Unit)? = null

    /**
     * Called whenever a chart flyout/modal/dropdown opens or closes.
     * Most hosts won't need this — [hasOpenUI] is maintained automatically and
     * [dismissAllUI] is the usual integration point.
     */
    var onUiStateChange: ((BridgeEvent.UiStateChange) -> Unit)? = null

    // ── UI dismissal ──────────────────────────────────────────────────────────

    /**
     * `true` when any chart flyout/modal/dropdown/popover is currently open.
     * Mirrored from the JS layer via `uiStateChange` events; read from the main thread.
     */
    @Volatile var hasOpenUI: Boolean = false
        private set

    /**
     * Dismisses any open chart UI (flyouts, modals, dropdowns, popovers) and returns
     * whether anything was dismissed.
     *
     * Wire this to your Activity's back-press handler: consume the back event only
     * when this returns `true`, otherwise let the normal back behavior proceed.
     *
     * ```kotlin
     * onBackPressedDispatcher.addCallback(this) {
     *     if (!chart.dismissAllUI()) {
     *         isEnabled = false
     *         onBackPressedDispatcher.onBackPressed()
     *     }
     * }
     * ```
     *
     * @return `true` if a flyout/modal was dismissed; `false` if nothing was open.
     */
    fun dismissAllUI(): Boolean {
        if (!hasOpenUI) return false
        sendCommand(BridgeCommand.DismissAllUI)
        return true
    }

    /**
     * Called when the chart engine requests data for a time range.
     *
     * Implement this to serve data requests from the chart. Fetch bars for the given
     * [BridgeEvent.DataRequest.timeframe]/[BridgeEvent.DataRequest.interval] and
     * [BridgeEvent.DataRequest.start]/[BridgeEvent.DataRequest.end] timestamps
     * (milliseconds since epoch), then call [resolveDataRequest] to deliver the data.
     */
    var onDataRequest: ((BridgeEvent.DataRequest) -> Unit)? = null

    /**
     * Called when the user taps the symbol name and `onSymbolClick = true` was passed to [init].
     * No ISIN picker modal is shown when this callback is set via the init command.
     */
    var onSymbolClick: ((BridgeEvent.SymbolClick) -> Unit)? = null

    /**
     * Called when the user taps the "Ask AI" (✦) button in the mobile header and
     * `onAskAiClick = true` was passed to [init] (only meaningful with
     * `headerLayout = "mobile"`).
     */
    var onAskAiClick: (() -> Unit)? = null

    /**
     * Called when the user picks a layout preset or toggles a cross-pane sync
     * option in the chart-owned multi-layout popover. Fires only when
     * `enableMultipleLayouts = true` was passed to [init].
     */
    var onLayoutChange: ((BridgeEvent.LayoutChange) -> Unit)? = null

    /**
     * Called when the user picks Download or Copy from the chart-owned snapshot
     * popover. Fires only when `enableSnapshot = true` was passed to [init].
     * Use the supplied `dataUrl` (base64 PNG) to save via platform APIs.
     */
    var onSnapshot: ((BridgeEvent.Snapshot) -> Unit)? = null

    /**
     * Called when the chart engine needs bars for a compare symbol. Fetch
     * bars for the supplied symbol over the [BridgeEvent.CompareDataRequest.start]
     * / `.end` window at the requested [BridgeEvent.CompareDataRequest.interval],
     * then call [resolveCompareDataRequest] with the same `requestId`.
     */
    var onCompareDataRequest: ((BridgeEvent.CompareDataRequest) -> Unit)? = null

    /** Called when a compare symbol has been added and its bars resolved. */
    var onCompareAdded: ((BridgeEvent.CompareAdded) -> Unit)? = null

    /** Called when a compare symbol is removed (×, [removeCompare], or [clearCompares]). */
    var onCompareRemoved: ((BridgeEvent.CompareRemoved) -> Unit)? = null

    /** Called when adding a compare or fetching its bars fails. */
    var onCompareError: ((BridgeEvent.CompareError) -> Unit)? = null

    /** Called when a study instance is added. Keep [BridgeEvent.IndicatorAdded.instanceId]
     *  to later remove that specific instance via [removeIndicator]. */
    var onIndicatorAdded: ((BridgeEvent.IndicatorAdded) -> Unit)? = null

    /** Called when a study instance is removed (pill ×, settings dialog, or [removeIndicator]). */
    var onIndicatorRemoved: ((BridgeEvent.IndicatorRemoved) -> Unit)? = null

    /** Called when the chart engine reports an error. */
    var onError: ((BridgeEvent.Error) -> Unit)? = null

    /**
     * Generic fallback — called for every event including those that have a typed callback.
     * Useful for logging or forwarding all events to a single handler.
     */
    var onBridgeEvent: ((BridgeEvent) -> Unit)? = null

    // ── Event dispatcher ──────────────────────────────────────────────────────

    private fun dispatchEvent(event: BridgeEvent) {
        onBridgeEvent?.invoke(event)
        when (event) {
            is BridgeEvent.Ready -> {
                // Auto-init safety net: if the consumer never called init(), queue a
                // default Init so the JS engine is created and subsequent commands don't
                // silently fail with "Engine not initialized". Mirrors iOS's behaviour of
                // always sending an init command on construction.
                if (!userInitCalled) {
                    sendCommand(BridgeCommand.Init())
                }
                flushCommandQueue()
                skeletonView.visibility = View.GONE
                if (!hasCalledOnReady) {
                    hasCalledOnReady = true
                    onReady?.invoke()
                }
            }
            is BridgeEvent.Crosshair -> onCrosshair?.invoke(event)
            is BridgeEvent.BarClick -> onBarClick?.invoke(event)
            is BridgeEvent.ViewportChange -> onViewportChange?.invoke(event)
            is BridgeEvent.SeriesChange -> onSeriesChange?.invoke(event)
            is BridgeEvent.PriceSourceChange -> onPriceSourceChange?.invoke(event)
            is BridgeEvent.TimeframeChange -> onTimeframeChange?.invoke(event)
            is BridgeEvent.DurationChange -> onDurationChange?.invoke(event)
            is BridgeEvent.StateChange -> onStateChange?.invoke(event)
            is BridgeEvent.StateSnapshot -> onStateSnapshot?.invoke(event)
            is BridgeEvent.Catalog -> onCatalog?.invoke(event)
            is BridgeEvent.DataLoaded -> onDataLoaded?.invoke(event)
            is BridgeEvent.NewBar -> onNewBar?.invoke(event)
            is BridgeEvent.StreamStatus -> onStreamStatus?.invoke(event)
            is BridgeEvent.PlaceOrder          -> onPlaceOrder?.invoke(event)
            is BridgeEvent.TradeLevelClose     -> onTradeLevelClose?.invoke(event)
            is BridgeEvent.TradeLevelDrag      -> onTradeLevelDrag?.invoke(event)
            is BridgeEvent.TradeLevelEdit      -> onTradeLevelEdit?.invoke(event)
            is BridgeEvent.TradeLevelQtyChange -> onTradeLevelQtyChange?.invoke(event)
            is BridgeEvent.TradeLevelConfirmed -> onTradeLevelConfirmed?.invoke(event)
            is BridgeEvent.TradeLevelEditCancelled -> onTradeLevelEditCancelled?.invoke(event)
            is BridgeEvent.TradeLevelEditOpen         -> onTradeLevelEditOpen?.invoke(event)
            is BridgeEvent.TradeLevelBracketActivated -> onTradeLevelBracketActivated?.invoke(event)
            is BridgeEvent.DraftInitiated             -> onDraftInitiated?.invoke(event)
            is BridgeEvent.DraftCancelled      -> onDraftCancelled?.invoke(event)
            is BridgeEvent.TfcToggle           -> onTfcToggle?.invoke(event)
            is BridgeEvent.CrosshairToggle     -> onCrosshairToggle?.invoke(event)
            is BridgeEvent.OrderLineMoveStart  -> onOrderLineMoveStart?.invoke(event)
            is BridgeEvent.OrderLineMoving     -> onOrderLineMoving?.invoke(event)
            is BridgeEvent.OrderLineMoved      -> onOrderLineMoved?.invoke(event)
            is BridgeEvent.UiStateChange       -> {
                hasOpenUI = event.hasOpenUI
                onUiStateChange?.invoke(event)
            }
            is BridgeEvent.DataRequest         -> onDataRequest?.invoke(event)
            is BridgeEvent.SymbolClick         -> onSymbolClick?.invoke(event)
            is BridgeEvent.AskAiClick          -> onAskAiClick?.invoke()
            is BridgeEvent.LayoutChange        -> onLayoutChange?.invoke(event)
            is BridgeEvent.Snapshot            -> onSnapshot?.invoke(event)
            is BridgeEvent.CompareDataRequest  -> onCompareDataRequest?.invoke(event)
            is BridgeEvent.CompareAdded        -> onCompareAdded?.invoke(event)
            is BridgeEvent.CompareRemoved      -> onCompareRemoved?.invoke(event)
            is BridgeEvent.CompareError        -> onCompareError?.invoke(event)
            is BridgeEvent.IndicatorAdded      -> onIndicatorAdded?.invoke(event)
            is BridgeEvent.IndicatorRemoved    -> onIndicatorRemoved?.invoke(event)
            is BridgeEvent.Error               -> onError?.invoke(event)
            // No typed callback yet — these reach the host through [onBridgeEvent] above.
            is BridgeEvent.AutoScaleChange,
            is BridgeEvent.BarColorSourceChange,
            is BridgeEvent.CanvasOptionsChange,
            is BridgeEvent.ChartSettingsApplied,
            is BridgeEvent.CopyDrawingsToAllChange,
            is BridgeEvent.CursorModeChange,
            is BridgeEvent.DrawingCreated,
            is BridgeEvent.DrawingToolbarVisibility,
            is BridgeEvent.GoToDate,
            is BridgeEvent.IndicatorTemplateApplied,
            is BridgeEvent.IndicatorTemplateDeleted,
            is BridgeEvent.IndicatorTemplateSaved,
            is BridgeEvent.KeepDrawingModeChange,
            is BridgeEvent.LayoutApplied,
            is BridgeEvent.LayoutDeleted,
            is BridgeEvent.LayoutSaved,
            is BridgeEvent.MagnetModeChange,
            is BridgeEvent.PricePrecisionChange,
            is BridgeEvent.PriceScaleModeChange,
            is BridgeEvent.QuickSearchCommand,
            is BridgeEvent.ScalesChange,
            is BridgeEvent.SettingsTemplateApplied,
            is BridgeEvent.SettingsTemplateDeleted,
            is BridgeEvent.SettingsTemplateSaved,
            is BridgeEvent.SidePanelVisibility,
            is BridgeEvent.StatusLineChange,
            is BridgeEvent.TimezoneChange -> Unit
        }
    }

    // ── Public command API ────────────────────────────────────────────────────

    /**
     * Re-creates the chart engine with the given configuration.
     * Call this from [onReady] to apply settings before loading data.
     */
    fun init(
        theme: String = "dark",
        symbol: String? = null,
        /**
         * Contract specs for [symbol]. Lets the ruler report pips and money
         * instead of a bare price distance. Swap it with [setInstrument] when
         * the symbol changes.
         */
        instrument: InstrumentSpec? = null,
        /**
         * Account equity and per-trade risk used to size the Long/Short
         * position tools. Keep it current with [setAccount].
         */
        account: AccountSpec? = null,
        /**
         * Enable the reworked drawing tools as one switch: Long/Short Position in
         * a new Forecasting group, freehand Brush & Highlighter, and the full
         * Ruler readout. Default: false.
         */
        enableForecasting: Boolean? = null,
        series: String? = null,
        timeframe: String? = null,
        duration: String? = null,
        enableTrading: Boolean = false,
        showVolume: Boolean? = null,
        showUI: Boolean? = null,
        showDrawingTools: Boolean? = null,
        showBidAskLines: Boolean? = null,
        /** Show the Ask price line independently. `null` falls back to the
         *  legacy [showBidAskLines] behavior. */
        showAskLine: Boolean? = null,
        /** Show the Bid price line independently. `null` falls back to the
         *  legacy [showBidAskLines] behavior. */
        showBidLine: Boolean? = null,
        showActLogo: Boolean? = null,
        showCandleCountdown: Boolean? = null,
        candleCountdownTimeframes: List<String>? = null,
        disableCountdownOnMobile: Boolean? = null,
        maxSubPanes: Int? = null,
        mobileBarDivisor: Int? = null,
        /**
         * Minimum bars expected from the initial fetch before giving up. If fewer bars
         * are returned by [onDataRequest], the chart engine auto-widens the lookback
         * window and retries — handy for weekends, market closures, or sparse symbols.
         * Default: `10`.
         */
        minInitialBars: Int? = null,
        /**
         * Hard ceiling (in milliseconds) on fetch-window lookback for auto-widening
         * retries. Default: 365 days.
         */
        maxLookbackMs: Long? = null,
        /** Enable momentum (kinetic) scrolling on drag release. Default: `true`. */
        momentumScrollEnabled: Boolean? = null,
        /** Per-frame velocity decay factor, normalised to 60 fps. Clamped [0.80, 0.99]. Default: `0.95`. */
        momentumDecay: Double? = null,
        /** Minimum release velocity (px/ms) to trigger momentum. Default: `0.3`. */
        momentumThreshold: Double? = null,
        /** Maximum launch velocity (px/ms) for momentum. Default: `6.0`. */
        momentumMaxVelocity: Double? = null,
        targetCandleWidth: Double? = null,
        /** Which price drives live candle close/high/low: `"bid"` (default), `"ask"`,
         *  or `"ltp"` — build candles from the last traded price (exchange/dealing
         *  feeds); ticks without a valid LTP fall back to the bid. */
        tickClosePriceSource: String? = null,
        /** Show the LTP marker (dashed price line + axis tag). `null` (default):
         *  shown only in `"ltp"` mode. `true`: always shown when the feed supplies
         *  an LTP. `false`: hidden even in `"ltp"` mode. */
        showLtpPrice: Boolean? = null,
        /** Show a price-source dropdown in the chart header listing these sources,
         *  e.g. `listOf("ltp", "bid")` (dealing feeds). A user pick switches the
         *  live candle source and emits [BridgeEvent.PriceSourceChange]. Hidden
         *  when `null` or empty. */
        priceSourceSelector: List<String>? = null,
        tradesThresholdForHorizontalLine: Int? = null,
        tradeDisplayFilter: String? = null,
        positionRenderStyle: String? = null,
        hideLevelConfirmCancel: Boolean? = null,
        /**
         * Dismiss a selected/active trade level when the user clicks/taps outside it (reverts
         * any pending edits). When `false` (default) the level is preserved across outside
         * clicks — only ✓ / ✗ buttons, tapping the level itself, or removing it via `setLevels`
         * dismiss it. Set to `true` to restore the legacy outside-click-to-cancel behavior.
         * Default: `false`.
         */
        deselectActiveOnOutsideClick: Boolean? = null,
        /** Always render SL/TP bracket lines + price pills, even without hover. Default: `true`; pass `false` to show them only on hover/selection. */
        showTradeLevelsAlways: Boolean? = true,
        /** Show candle countdown timer on the right price axis under the live price tag. Default: `false`. */
        showPriceAxisCountdown: Boolean? = null,
        /**
         * Multiplier for trade-level Confirm/Cancel/Edit/Close button radii and gaps.
         * Scales visuals AND hit/drag areas together — useful for larger touch targets on tablets/phones.
         * Clamped to `[1.0, 3.0]`. Default: `1.0`.
         */
        tradeLevelButtonScale: Double? = null,
        bracketLabelMode: String? = null,
        currencySymbol: String? = null,
        /** Enable trade-level fan-out clustering. Overlapping levels are grouped into expandable badges. Default: `true`. */
        levelClusteringEnabled: Boolean? = null,
        /** Pixel proximity threshold for level clustering. Only effective when [levelClusteringEnabled] is `true`. Default: `20`. */
        clusterThresholdDistance: Int? = null,
        /** Enable TFC toggle button in the top bar. When `false`, TFC is completely disabled. Default: `true`. */
        tfcEnabled: Boolean? = null,
        /** Show the settings gear button in the top bar. Set to `false` to hide it entirely. Default: `true`. */
        showSettings: Boolean? = null,
        /**
         * Hide the symbol name and tick-activity (streaming) dot in the top-left overlay.
         * Does **not** affect the OHLC(V) strip — use [hideOHLCV] for that. Default: `false`.
         */
        hideSymbolAndTick: Boolean? = null,
        /**
         * Hide the OHLC(V) data strip (`O: H: L: C: V:`) in the top-left overlay.
         * Independent of [hideSymbolAndTick] — set both to `true` to hide the entire overlay.
         * Default: `false`.
         */
        hideOHLCV: Boolean? = null,
        /** Show the bottom duration-selector bar. Default: `false` (hidden). */
        showBottomBar: Boolean? = null,
        /** Show the fullscreen toggle button in the top bar. Default: `false` (hidden on mobile). */
        showFullscreenButton: Boolean = false,
        /** Per-timeframe base interval override for client-side aggregation, e.g. `mapOf("1h" to "30m")`. */
        aggregateFrom: Map<String, String>? = null,
        /** Per-theme canvas background color overrides as a raw JSON string. */
        canvasColorsJson: String? = null,
        /** Per-theme deep-partial color overrides for the built-in themes as a raw JSON string. */
        themeOverridesJson: String? = null,
        /** Per-theme deep-partial color overrides (typed). Takes precedence over [themeOverridesJson] when both are set. */
        themeOverrides: ThemeOverrides? = null,
        /** User-visible string overrides for i18n/localisation as a raw JSON string. */
        labelsJson: String? = null,
        /** Per-component UI configuration overrides as a raw JSON string. */
        uiConfigJson: String? = null,
        /** Override the default duration → timeframe pairings, e.g. `mapOf("1Y" to "1D")`. */
        durationTimeframeMap: Map<String, String>? = null,
        /** When true, fires [BridgeEvent.SymbolClick] on symbol tap instead of opening the picker modal. */
        onSymbolClick: Boolean = false,
        /**
         * When true, the `"mobile"` header renders an "Ask AI" (✦) button that fires
         * [BridgeEvent.AskAiClick] on tap. No effect in other header layouts. Default: `false`.
         */
        onAskAiClick: Boolean = false,
        /** IANA timezone string for time-axis and crosshair labels. Default: `"UTC"`. */
        timezone: String? = null,
        /**
         * Top-bar variant. `"simple"` (default) is the classic TopBar; `"advanced"`
         * is the pill-style AdvancedToolbar; `"compact"` is the slim per-pane
         * CompactToolbar (intended for cells of a host-rendered multi-pane grid);
         * `"mobile"` renders the compact mobile header (Tools · timeframe pills ·
         * optional Ask AI button).
         */
        headerLayout: String? = null,
        /**
         * Enables the chart-owned multi-layout popover (Layout button → 26 preset
         * picker + cross-pane sync toggles). Fires [BridgeEvent.LayoutChange] on
         * selection. The host is still responsible for mounting / tearing down
         * additional panes — the chart only emits intent.
         */
        enableMultipleLayouts: Boolean? = null,
        /**
         * Enables the chart-owned snapshot popover (Snapshot button → Download / Copy).
         * Fires [BridgeEvent.Snapshot] with a base64 PNG so the native layer can
         * intercept and save via platform APIs (MediaStore, ClipboardManager).
         */
        enableSnapshot: Boolean? = null,
        /**
         * Hides the chart header entirely (whichever variant [headerLayout] would
         * have rendered). Bottom bar, drawing tools, and on-canvas overlays remain
         * on their own flags. Use when the host app provides its own controls and
         * drives the chart via [BridgeCommand.SetTimeframe], [BridgeCommand.SetSeries],
         * [BridgeCommand.AddIndicatorByName], [BridgeCommand.RemoveIndicator].
         * Default: `false` (header visible).
         */
        hideHeader: Boolean? = null,
        /**
         * Compare symbols to add automatically on chart init. Each entry triggers
         * a [BridgeEvent.CompareDataRequest] against the initial primary range —
         * respond via [resolveCompareDataRequest].
         */
        initialCompares: List<String>? = null,
        /** Maximum concurrent compare symbols. Adding beyond emits [BridgeEvent.CompareError]. Default: `8`. */
        maxCompares: Int? = null,
        /**
         * Initial state of the layout popover's cross-pane sync toggles (only
         * meaningful with [enableMultipleLayouts]). Partial — `null` fields use the
         * library default. Change later on a live chart via [setLayoutSync].
         */
        layoutSync: LayoutSync? = null,
        /**
         * Puts a crosshair on/off switch in the chart header. The crosshair starts on (see
         * [crosshairEnabled]) so the icon is tinted; tapping it hides the crosshair — and the
         * floating trade button that rides on it — and drops the icon to its plain state;
         * tapping again brings both back. Fires [onCrosshairToggle]. Default: `false`.
         */
        enableCrossHairHeader: Boolean? = null,
        /**
         * Whether the crosshair is drawn at all. `false` hides it and the floating trade
         * button until [setCrosshairEnabled] turns it back on — use it to restore a
         * persisted [onCrosshairToggle] choice. Default: `true`.
         */
        crosshairEnabled: Boolean? = null,
        /**
         * Enables horizontal (time-axis) order-line dragging for levels flagged
         * `"timeDraggable" to true` in [setLevels] — open positions and pending orders alike.
         * Sideways drags keep the price locked and fire [onOrderLineMoved]; a pending order's
         * badge still drags vertically to move its entry price (the first movement picks the
         * axis). Broker-gated — enable only for the users who should have it. Default: `false`.
         */
        orderLineTimeDrag: Boolean? = null,
        /** Snap a horizontally dragged badge to the nearest candle on release. Default: `true`. */
        orderLineDragSnap: Boolean? = null,
        /** Remember dropped badge positions in the WebView's `localStorage` across reloads. Default: `true`. */
        orderLineAnchorPersistence: Boolean? = null,
        /** Where an un-dragged `timeDraggable` badge sits: `"timestamp"` (default) or `"center"`. */
        orderLineDefaultAnchor: String? = null,
        /**
         * Widen the price axis when a level gains a new SL/TP that sits outside the
         * visible range, so the line placed from your order form comes into view.
         * Default: `false`.
         */
        revealNewBrackets: Boolean? = null,
        /**
         * Shows the Templates block at the foot of the indicators flyout — named,
         * reusable indicator sets. No new header button. The chart persists nothing:
         * it emits [BridgeEvent.IndicatorTemplateSaved] and your app stores the
         * template. Default: `false`.
         */
        enableIndicatorTemplates: Boolean? = null,
        /** Indicator templates to list at init — a JSON array, typically what you stored. */
        indicatorTemplatesJson: String? = null,
        /**
         * Shows the Templates row and the "Apply to all charts" switch in the Chart
         * Settings dialog. Default: `false`.
         */
        enableSettingsTemplates: Boolean? = null,
        /** Settings templates to list at init — a JSON array. */
        settingsTemplatesJson: String? = null,
        /**
         * Shows the Saved layouts section in the layout popover — a grid preset plus
         * every pane's full state. Requires [enableMultipleLayouts]. Default: `false`.
         */
        enableSavedLayouts: Boolean? = null,
        /** Saved layouts to list at init — a JSON array. */
        savedLayoutsJson: String? = null,
        /**
         * Enables Quick Search, the command palette over everything the chart can do.
         * Android has no Ctrl/⌘+K, so open it with [openQuickSearch]. Default: `false`.
         */
        enableQuickSearch: Boolean? = null,
        /** Adds a search button to the header for [enableQuickSearch]. Default: `false`. */
        quickSearchShowButton: Boolean? = null,
        /**
         * Box/reversal parameters for the price-transform chart types (Renko,
         * Line Break, Kagi, Point & Figure) as a JSON object. Omit for ATR(14).
         */
        seriesOptionsJson: String? = null,
        /** Initial pointer mode: `"cross"` (default), `"dot"`, `"arrow"`, `"demonstration"` or `"eraser"`. */
        cursorMode: String? = null,
        /** Show an OHLCV readout beside a long press. Default: `false`. */
        valueTooltip: Boolean? = null,
        /** Add the Cursors group to the top of the drawing toolbar. Default: `false`. */
        enableCursorModes: Boolean? = null,
        enableIconTools: Boolean? = null,
        enableChartSettings: Boolean? = null,
        statusLineJson: String? = null,
        scalesJson: String? = null,
        canvasJson: String? = null,
        barColorSource: String? = null,
        enableScaleControls: Boolean? = null,
        priceScaleMode: String? = null,
        autoScale: Boolean? = null,
        enableSidePanels: Boolean? = null,
        /** Snap drawing points to bar OHLC values. Default: `false`. */
        magnetMode: Boolean? = null,
        /** Keep the drawing tool armed after each drawing. Default: `false`. */
        keepDrawingMode: Boolean? = null,
        /** Announce new drawings for layout-wide replication. Default: `false`. */
        copyDrawingsToAllCharts: Boolean? = null,
        /**
         * Raw JSON string from a prior [onStateSnapshot] callback. When provided, the full chart state
         * (timeframe, series, indicators, drawings, etc.) is restored atomically alongside the init
         * command — both are evaluated in a single `evaluateJavascript` call, so there is no
         * intermediate "1D" flash before the saved timeframe is applied.
         */
        stateJson: String? = null,
    ): Unit {
        applyNativeTheme(theme)
        val initCmd = BridgeCommand.Init(
        theme = theme, symbol = symbol, instrument = instrument, account = account,
        enableForecasting = enableForecasting,
        series = series, timeframe = timeframe,
        duration = duration, enableTrading = enableTrading,
        showVolume = showVolume, showUI = showUI, showDrawingTools = showDrawingTools,
        showBidAskLines = showBidAskLines, showAskLine = showAskLine,
        showBidLine = showBidLine, showActLogo = showActLogo,
        showCandleCountdown = showCandleCountdown,
        candleCountdownTimeframes = candleCountdownTimeframes,
        disableCountdownOnMobile = disableCountdownOnMobile,
        maxSubPanes = maxSubPanes, mobileBarDivisor = mobileBarDivisor,
        minInitialBars = minInitialBars, maxLookbackMs = maxLookbackMs,
        momentumScrollEnabled = momentumScrollEnabled, momentumDecay = momentumDecay,
        momentumThreshold = momentumThreshold, momentumMaxVelocity = momentumMaxVelocity,
        targetCandleWidth = targetCandleWidth, tickClosePriceSource = tickClosePriceSource,
        showLtpPrice = showLtpPrice, priceSourceSelector = priceSourceSelector,
        tradesThresholdForHorizontalLine = tradesThresholdForHorizontalLine,
        tradeDisplayFilter = tradeDisplayFilter, positionRenderStyle = positionRenderStyle,
        hideLevelConfirmCancel = hideLevelConfirmCancel,
        deselectActiveOnOutsideClick = deselectActiveOnOutsideClick,
        showTradeLevelsAlways = showTradeLevelsAlways,
        showPriceAxisCountdown = showPriceAxisCountdown,
        tradeLevelButtonScale = tradeLevelButtonScale,
        bracketLabelMode = bracketLabelMode,
        currencySymbol = currencySymbol,
        levelClusteringEnabled = levelClusteringEnabled, clusterThresholdDistance = clusterThresholdDistance,
        tfcEnabled = tfcEnabled,
        showSettings = showSettings,
        hideSymbolAndTick = hideSymbolAndTick, hideOHLCV = hideOHLCV, showBottomBar = showBottomBar,
        showFullscreenButton = showFullscreenButton,
        aggregateFrom = aggregateFrom, canvasColorsJson = canvasColorsJson,
        themeOverridesJson = themeOverridesJson ?: themeOverrides?.toJsonString(), labelsJson = labelsJson,
        uiConfigJson = uiConfigJson, durationTimeframeMap = durationTimeframeMap,
        onSymbolClick = onSymbolClick,
        onAskAiClick = onAskAiClick,
        timezone = timezone,
        headerLayout = headerLayout,
        enableMultipleLayouts = enableMultipleLayouts,
        enableSnapshot = enableSnapshot,
        hideHeader = hideHeader,
        initialCompares = initialCompares,
        maxCompares = maxCompares,
        layoutSync = layoutSync,
        enableCrossHairHeader = enableCrossHairHeader,
        crosshairEnabled = crosshairEnabled,
        orderLineTimeDrag = orderLineTimeDrag,
        orderLineDragSnap = orderLineDragSnap,
        orderLineAnchorPersistence = orderLineAnchorPersistence,
        orderLineDefaultAnchor = orderLineDefaultAnchor,
        revealNewBrackets = revealNewBrackets,
        enableIndicatorTemplates = enableIndicatorTemplates,
        indicatorTemplatesJson = indicatorTemplatesJson,
        enableSettingsTemplates = enableSettingsTemplates,
        settingsTemplatesJson = settingsTemplatesJson,
        enableSavedLayouts = enableSavedLayouts,
        savedLayoutsJson = savedLayoutsJson,
        enableQuickSearch = enableQuickSearch,
        quickSearchShowButton = quickSearchShowButton,
        seriesOptionsJson = seriesOptionsJson,
        cursorMode = cursorMode,
        valueTooltip = valueTooltip,
        enableCursorModes = enableCursorModes,
        enableIconTools = enableIconTools,
        enableChartSettings = enableChartSettings,
        statusLineJson = statusLineJson,
        scalesJson = scalesJson,
        canvasJson = canvasJson,
        barColorSource = barColorSource,
        enableScaleControls = enableScaleControls,
        priceScaleMode = priceScaleMode,
        autoScale = autoScale,
        enableSidePanels = enableSidePanels,
        magnetMode = magnetMode,
        keepDrawingMode = keepDrawingMode,
        copyDrawingsToAllCharts = copyDrawingsToAllCharts,
        )
        if (stateJson == null) {
            sendCommand(initCmd)
        } else {
            // Evaluate init + setState in a single evaluateJavascript call so the engine
            // never renders a frame with the default "1D" timeframe before state is restored.
            evalBatch(listOf(initCmd.toJson(), BridgeCommand.SetState(stateJson).toJson()))
        }
    }

    /**
     * Loads a full dataset into the chart and optionally fits all bars into view.
     * Emits [BridgeEvent.DataLoaded] on completion.
     */
    fun loadData(bars: List<OHLCVBar>, fitAll: Boolean = false) =
        sendCommand(BridgeCommand.LoadData(bars, fitAll))

    /** Switches between `"dark"` and `"light"` themes. */
    fun setTheme(theme: String) {
        applyNativeTheme(theme)
        sendCommand(BridgeCommand.SetTheme(theme))
    }

    /**
     * Changes the display timezone for time-axis and crosshair labels.
     * Accepts any IANA string (e.g. `"America/New_York"`), `"UTC"`, or `"local"`.
     */
    fun setTimezone(timezone: String) = sendCommand(BridgeCommand.SetTimezone(timezone))

    /**
     * Updates the chart-owned layout popover's cross-pane sync toggles (Symbol /
     * Interval / Crosshair / Time / Date range). Partial — `null` fields keep
     * their current value. Only has an effect when `enableMultipleLayouts = true`
     * was passed to [init]. Use to restore a user's persisted sync preferences.
     */
    fun setLayoutSync(sync: LayoutSync) = sendCommand(BridgeCommand.SetLayoutSync(sync))

    /**
     * Shows or hides the crosshair at runtime — and with it the floating trade button that
     * rides on it. Same effect as tapping the header switch (`enableCrossHairHeader` in
     * [init]): the switch follows, and [onCrosshairToggle] fires when the state changes.
     */
    fun setCrosshairEnabled(enabled: Boolean) = sendCommand(BridgeCommand.SetCrosshairEnabled(enabled))

    /**
     * Changes the chart series type.
     * Valid values: `"candlestick"`, `"hollow_candle"`, `"line"`, `"area"`, `"ohlc"`.
     */
    fun setSeries(series: String) = sendCommand(BridgeCommand.SetSeries(series))

    /** Changes the active timeframe (e.g. `"1m"`, `"1h"`, `"1D"`). */
    fun setTimeframe(timeframe: String) = sendCommand(BridgeCommand.SetTimeframe(timeframe))

    /**
     * Selects a chart duration (`"1D"`, `"5D"`, `"1M"`, `"3M"`, `"6M"`, `"1Y"`,
     * `"5Y"`, `"All"`) and refetches. The timeframe is paired automatically
     * unless [timeframe] is supplied. The x-axis rescales from the new bars, so
     * the chart never needs reinitialising when the interval changes.
     */
    fun setDuration(duration: String, timeframe: String? = null) =
        sendCommand(BridgeCommand.SetDuration(duration, timeframe))

    /**
     * Switches the SL/TP bracket pills between the bracket price (`"price"`,
     * the default) and the money that bracket is worth (`"amount"`, e.g.
     * `SL -$290.80`). Amount mode needs each level to carry `lots` plus
     * `contractSize` / `valuePerPoint`; levels without them keep showing prices.
     */
    fun setBracketLabelMode(mode: String, currencySymbol: String? = null) =
        sendCommand(BridgeCommand.SetBracketLabelMode(mode, currencySymbol))

    /**
     * Pushes a live tick for streaming updates.
     * The bridge aggregates ticks into the current candle; use [loadData] for bulk replacement.
     *
     * @param ltp Last traded price — optional, sent by exchange/dealing feeds and
     *   consumed when `tickClosePriceSource = "ltp"`; ticks without it fall back to the bid.
     * @param ltpv Last traded volume — optional, accompanies [ltp] on trade ticks.
     */
    @JvmOverloads
    fun pushTick(bid: Double, ask: Double, timestamp: Long, ltp: Double? = null, ltpv: Double? = null) =
        sendCommand(BridgeCommand.PushTick(bid, ask, timestamp, ltp, ltpv))

    /**
     * Shows/hides the LTP (last traded price) marker — dashed line + axis tag.
     * Pass `null` to restore the default (shown only when `tickClosePriceSource = "ltp"`).
     */
    @JvmOverloads
    fun setShowLtpPrice(show: Boolean? = null) =
        sendCommand(BridgeCommand.SetShowLtpPrice(show))

    /**
     * Switches which price drives live candle close/high/low at runtime
     * (`"bid"`, `"ask"` or `"ltp"`). Also syncs the header price-source
     * dropdown when `priceSourceSelector` is enabled. Programmatic calls do
     * not emit [BridgeEvent.PriceSourceChange] — that event fires only for
     * user picks from the dropdown.
     */
    fun setTickClosePriceSource(source: String) =
        sendCommand(BridgeCommand.SetTickClosePriceSource(source))

    /**
     * Adds a study by short name (e.g. `"SMA"`, `"EMA"`, `"RSI"`, `"BB"`).
     *
     * Parameterized studies support multiple simultaneous instances: each call
     * adds a new instance (with an auto-cycled color). Listen to [onIndicatorAdded]
     * for the resulting `instanceId`. A few studies are single-instance and toggle
     * instead (`VOL`, `OBV`, `A/D`, `AO`, `VWAP`, `Ichimoku`, `PSAR`, `Pivot`, `HA`).
     *
     * @param params Optional parameters, e.g. `mapOf("period" to 20)`.
     */
    fun addIndicator(name: String, params: Map<String, Any>? = null) =
        sendCommand(BridgeCommand.AddIndicator(name, params))

    /**
     * Removes a study. Pass an `instanceId` (e.g. `"EMA#3"`, from [onIndicatorAdded])
     * to remove that single instance, or a short name (e.g. `"EMA"`) to remove **all**
     * instances of that study.
     */
    fun removeIndicator(name: String) = sendCommand(BridgeCommand.RemoveIndicator(name))

    /**
     * Activates a drawing tool by ID (e.g. `"trend_line"`, `"horizontal_line"`).
     * Pass `null` to deactivate the current drawing tool.
     */
    fun setDrawingTool(tool: String?) = sendCommand(BridgeCommand.SetDrawingTool(tool))

    /** Removes all drawings from the chart. */
    fun clearAllDrawings() = sendCommand(BridgeCommand.ClearAllDrawings)

    /** Chooses what the status line shows, e.g. `{"barChange":true}`. Merges. */
    fun setStatusLineSettings(statusLineJson: String) =
        sendCommand(BridgeCommand.SetStatusLineSettings(statusLineJson))

    /** Price/time axis options, e.g. `{"timezone":"Asia/Tokyo"}`. Merges. */
    fun setScalesSettings(scalesJson: String) =
        sendCommand(BridgeCommand.SetScalesSettings(scalesJson))

    /** Grid, watermark and crosshair options, e.g. `{"gridVertical":false}`. Merges. */
    fun setCanvasOptions(canvasJson: String) =
        sendCommand(BridgeCommand.SetCanvasOptions(canvasJson))

    /** `"open"` (default) or `"previousClose"` bar colouring. */
    fun setBarColorSource(source: String) =
        sendCommand(BridgeCommand.SetBarColorSource(source))

    /** Decimal places for prices; null re-infers them from the feed. */
    fun setPricePrecision(digits: Int?) =
        sendCommand(BridgeCommand.SetPricePrecision(digits))

    /** `"normal"` (default), `"log"` or `"percent"` price axis. */
    fun setPriceScaleMode(mode: String) =
        sendCommand(BridgeCommand.SetPriceScaleMode(mode))

    /** Turns automatic Y-range fitting on or off. */
    fun setAutoScale(enabled: Boolean) =
        sendCommand(BridgeCommand.SetAutoScale(enabled))

    /** Scrolls to a date, centring the nearest bar. ISO 8601 or unix ms. */
    fun goToDate(date: String) =
        sendCommand(BridgeCommand.GoToDate(date))

    /** Shows or hides the docked Data Window / Objects panel. */
    fun setSidePanelVisible(visible: Boolean) =
        sendCommand(BridgeCommand.SetSidePanelVisible(visible))

    /** Switches the panel. [tab] is `"data"` or `"objects"`. */
    fun setSidePanelTab(tab: String) =
        sendCommand(BridgeCommand.SetSidePanelTab(tab))

    /** Shows or hides one drawing by id. */
    fun setDrawingVisible(id: String, visible: Boolean) =
        sendCommand(BridgeCommand.SetDrawingVisible(id, visible))

    /** Locks or unlocks one drawing by id. */
    fun setDrawingLocked(id: String, locked: Boolean) =
        sendCommand(BridgeCommand.SetDrawingLocked(id, locked))

    /** Deletes one drawing by id. */
    fun deleteDrawing(id: String) =
        sendCommand(BridgeCommand.DeleteDrawing(id))

    /** Selects a drawing by id; null clears the selection. */
    fun selectDrawing(id: String?) =
        sendCommand(BridgeCommand.SelectDrawing(id))

    /**
     * Appends one drawing, leaving the existing ones alone.
     *
     * This is how copy-to-all-charts lands: the chart the user drew on emits
     * [BridgeEvent.DrawingCreated], and you forward its `drawingJson` to every
     * other chart view in the layout. The chart cannot do this itself — only
     * your app knows which panes exist.
     */
    fun addDrawing(drawingJson: String) = sendCommand(BridgeCommand.AddDrawing(drawingJson))

    /** Updates the displayed symbol name in the chart's top bar. */
    fun setSymbol(symbol: String) = sendCommand(BridgeCommand.SetSymbol(symbol))

    /**
     * Replaces the contract specs the measurement tools use to report pips and
     * money. Pair it with [setSymbol]; pass `null` to clear them.
     *
     * @see InstrumentSpec
     */
    fun setInstrument(instrument: InstrumentSpec?) =
        sendCommand(BridgeCommand.SetInstrument(instrument))

    /**
     * Updates the account equity and per-trade risk the Long/Short position
     * tools size against. Push it whenever equity moves; `null` clears it.
     *
     * @see AccountSpec
     */
    fun setAccount(account: AccountSpec?) = sendCommand(BridgeCommand.SetAccount(account))

    /**
     * Requests the current chart state.
     * The result is delivered asynchronously via [onStateSnapshot].
     */
    fun getState() = sendCommand(BridgeCommand.GetState)

    /**
     * Asks the chart to send the native-UI catalog again; it arrives in [onCatalog].
     * Not needed on start-up — the chart sends it automatically after [init].
     */
    fun getCatalog() = sendCommand(BridgeCommand.GetCatalog)

    /**
     * Restores a previously captured chart state.
     * @param stateJson Raw JSON string from a prior [onStateSnapshot] callback.
     */
    fun setState(stateJson: String) = sendCommand(BridgeCommand.SetState(stateJson))

    /**
     * Resolves a pending data request from the chart engine with fetched bars.
     *
     * Call this from [onDataRequest] after fetching the required data.
     * @param requestId The [BridgeEvent.DataRequest.requestId] received in the event.
     * @param bars The OHLCV bars covering the requested time range.
     */
    fun resolveDataRequest(requestId: String, bars: List<OHLCVBar>) =
        sendCommand(BridgeCommand.ResolveDataRequest(requestId, bars))

    // ── Compare ───────────────────────────────────────────────────────────────

    /**
     * Adds a compare symbol overlay. The chart fires [BridgeEvent.CompareDataRequest]
     * with the primary chart's current timeframe / range; respond by calling
     * [resolveCompareDataRequest] with the fetched bars.
     */
    fun addCompare(symbol: String) = sendCommand(BridgeCommand.AddCompare(symbol))

    /** Removes a compare symbol. No-op when not active. */
    fun removeCompare(symbol: String) = sendCommand(BridgeCommand.RemoveCompare(symbol))

    /** Removes every active compare symbol. */
    fun clearCompares() = sendCommand(BridgeCommand.ClearCompares)

    /**
     * Resolves a pending [BridgeEvent.CompareDataRequest] with fetched bars.
     * Call this from [onCompareDataRequest] once the historical bars are ready.
     */
    fun resolveCompareDataRequest(requestId: String, bars: List<OHLCVBar>) =
        sendCommand(BridgeCommand.ResolveCompareDataRequest(requestId, bars))

    // ── Snapshot ──────────────────────────────────────────────────────────────

    /**
     * Captures the chart without the user opening the snapshot popover.
     *
     * The PNG arrives on [BridgeEvent.Snapshot] as a `data:` URL — decode it and
     * save or share it yourself; the in-WebView browser download does not work on
     * Android. Requires `enableSnapshot` in the init command.
     */
    fun requestSnapshot(action: String = "download") =
        sendCommand(BridgeCommand.RequestSnapshot(action))

    // ── Indicator templates ───────────────────────────────────────────────────

    /**
     * Replaces the templates listed in the indicators flyout.
     *
     * @param templatesJson A JSON array of templates — the ones your app stored
     *   from [BridgeEvent.IndicatorTemplateSaved].
     */
    fun setIndicatorTemplates(templatesJson: String) =
        sendCommand(BridgeCommand.SetIndicatorTemplates(templatesJson))

    /** Saves the chart's current indicators; replies on [BridgeEvent.IndicatorTemplateSaved]. */
    fun captureIndicatorTemplate(name: String) =
        sendCommand(BridgeCommand.CaptureIndicatorTemplate(name))

    /** Replaces the chart's indicators with a template's. Accepts the id or the name. */
    fun applyIndicatorTemplate(id: String) =
        sendCommand(BridgeCommand.ApplyIndicatorTemplate(id))

    /** Removes a template from the flyout. Delete it from your storage too. */
    fun deleteIndicatorTemplate(id: String) =
        sendCommand(BridgeCommand.DeleteIndicatorTemplate(id))

    // ── Chart-settings templates ──────────────────────────────────────────────

    /** Replaces the templates listed in the Chart Settings dialog. */
    fun setSettingsTemplates(templatesJson: String) =
        sendCommand(BridgeCommand.SetSettingsTemplates(templatesJson))

    /** Saves the chart's current settings; replies on [BridgeEvent.SettingsTemplateSaved]. */
    fun captureSettingsTemplate(name: String) =
        sendCommand(BridgeCommand.CaptureSettingsTemplate(name))

    /** Applies a saved settings template. Accepts the id or the name. */
    fun applySettingsTemplate(id: String) =
        sendCommand(BridgeCommand.ApplySettingsTemplate(id))

    /** Removes a settings template. Delete it from your storage too. */
    fun deleteSettingsTemplate(id: String) =
        sendCommand(BridgeCommand.DeleteSettingsTemplate(id))

    /**
     * Applies a settings snapshot to this chart.
     *
     * This is the "Apply to all charts" fan-out: when
     * [BridgeEvent.ChartSettingsApplied] arrives with `applyToAll == true`, pass its
     * `settingsJson` to every other chart view you have mounted.
     */
    fun applyChartSettings(settingsJson: String) =
        sendCommand(BridgeCommand.ApplyChartSettings(settingsJson))

    // ── Saved layouts ─────────────────────────────────────────────────────────

    /** Replaces the layouts listed in the layout popover. */
    fun setSavedLayouts(layoutsJson: String) =
        sendCommand(BridgeCommand.SetSavedLayouts(layoutsJson))

    /**
     * Saves the current preset and this chart's state; replies on [BridgeEvent.LayoutSaved].
     *
     * @param paneId Identifies this chart within the layout — leave at `"main"` for a
     *   single-chart screen, pass a distinct id per pane in a grid.
     */
    fun captureSavedLayout(name: String, paneId: String = "main") =
        sendCommand(BridgeCommand.CaptureSavedLayout(name, paneId))

    /** Restores a saved layout into this chart. Accepts the id or the name. */
    fun applySavedLayout(id: String, paneId: String = "main") =
        sendCommand(BridgeCommand.ApplySavedLayout(id, paneId))

    /** Removes a saved layout. Delete it from your storage too. */
    fun deleteSavedLayout(id: String) = sendCommand(BridgeCommand.DeleteSavedLayout(id))

    /**
     * Selects a grid preset. Emits [BridgeEvent.LayoutChange]; mounting the panes
     * stays your app's job.
     */
    fun setLayoutPreset(presetId: String) = sendCommand(BridgeCommand.SetLayoutPreset(presetId))

    // ── Drawing toolbar options ───────────────────────────────────────────────

    /** Snaps drawing points to the nearest OHLC of the bar under the cursor. */
    fun setMagnetMode(enabled: Boolean) = sendCommand(BridgeCommand.SetMagnetMode(enabled))

    /** Keeps the active tool armed after each drawing, for placing a series. */
    fun setKeepDrawingMode(enabled: Boolean) = sendCommand(BridgeCommand.SetKeepDrawingMode(enabled))

    /**
     * Announces new drawings via [BridgeEvent.DrawingCreated] so your app can
     * replicate them across the other panes of a layout.
     */
    fun setCopyDrawingsToAllCharts(enabled: Boolean) =
        sendCommand(BridgeCommand.SetCopyDrawingsToAllCharts(enabled))

    /** Shows or hides the drawing toolbar at runtime. */
    fun setDrawingToolbarVisible(visible: Boolean) =
        sendCommand(BridgeCommand.SetDrawingToolbarVisible(visible))

    // ── Cursors ───────────────────────────────────────────────────────────────

    /**
     * Switches pointer behaviour over the plot.
     *
     * Independent of the drawing tool — switching mode never cancels a drawing in
     * progress. Replies with [BridgeEvent.CursorModeChange].
     *
     * @param mode `"cross"`, `"dot"`, `"arrow"`, `"demonstration"` or `"eraser"`.
     */
    fun setCursorMode(mode: String) = sendCommand(BridgeCommand.SetCursorMode(mode))

    // ── Chart types ───────────────────────────────────────────────────────────

    /**
     * Retunes the price-transform chart types — Renko, Line Break, Kagi and
     * Point & Figure.
     *
     * Merged over the current options, so one series can be retuned without
     * disturbing the others. The chart *type* is still chosen with [setSeries]:
     * `"hlc"`, `"renko"`, `"linebreak"`, `"kagi"` and `"pointfigure"` are new
     * values of the same series string.
     */
    fun setSeriesOptions(optionsJson: String) =
        sendCommand(BridgeCommand.SetSeriesOptions(optionsJson))

    // ── Quick Search ──────────────────────────────────────────────────────────

    /**
     * Opens the command palette over everything the chart can do.
     *
     * The web build opens this with Ctrl/⌘+K or `/`; Android has neither, so this is
     * the entry point — wire it to a toolbar item. Requires `enableQuickSearch` in
     * the init command.
     */
    fun openQuickSearch() = sendCommand(BridgeCommand.OpenQuickSearch)

    /** Closes the command palette. Useful from a back-press handler. */
    fun closeQuickSearch() = sendCommand(BridgeCommand.CloseQuickSearch)

    /**
     * Enables or disables verbose tick/render logging in the browser console.
     *
     * Useful for diagnosing live candle or streaming issues during development.
     */
    fun setDebug(enabled: Boolean) = sendCommand(BridgeCommand.SetDebug(enabled))

    /** Destroys the chart engine and releases WebView resources. */
    fun destroy() {
        sendCommand(BridgeCommand.Destroy)
        mainHandler.postDelayed({
            webView.stopLoading()
            webView.destroy()
        }, 200)
    }

    // ── Trade levels ──────────────────────────────────────────────────────────

    /**
     * Replaces all levels of the given [type] with [levels].
     * Each map in [levels] must contain at least the [labelKey] and [priceKey] fields.
     * Optional per-entry fields: `side`, `stopLossPrice`, `takeProfitPrice`,
     * `pnl`, `pnlText`, `text`, `lots`, `orderType`, `entryPriceEditable`.
     * @param type `"position"`, `"pending"`, or `"trade"`.
     */
    fun setLevels(
        levels: List<Map<String, Any>>,
        labelKey: String,
        priceKey: String,
        type: String,
        pnlKey: String? = null,
        pnlTextKey: String? = null,
    ) = sendCommand(BridgeCommand.SetLevels(levels, labelKey, priceKey, type, pnlKey, pnlTextKey))

    /** Removes a single level by its label. No-op if not found. */
    fun removeLevelByLabel(label: String) =
        sendCommand(BridgeCommand.RemoveLevelByLabel(label))

    /** Updates the entry price of an existing level. */
    fun updateLevelMainPrice(label: String, price: Double) =
        sendCommand(BridgeCommand.UpdateLevelMainPrice(label, price))

    /**
     * Update the quantity shown on an existing level's pill — the counterpart of
     * [updateLevelMainPrice] for lots. Call it when your modify panel changes the
     * size, so the chart stops showing the broker's old quantity while the modify
     * is in flight. Staged like a chart-side qty edit: it survives [setLevels]
     * refreshes, rides along in `onTradeLevelEdit`, and is reverted by
     * [cancelCurrentEdit].
     */
    fun updateLevelQty(label: String, qty: Double) =
        sendCommand(BridgeCommand.UpdateLevelQty(label, qty))

    /**
     * Updates or removes a SL/TP bracket on an existing level.
     * @param bracketType `"sl"` or `"tp"`.
     * @param price Pass `null` to remove the bracket.
     */
    fun updateLevelBracket(label: String, bracketType: String, price: Double?) =
        sendCommand(BridgeCommand.UpdateLevelBracket(label, bracketType, price))

    /**
     * Adds a SL or TP bracket to an existing level at an auto-computed default price.
     * The chart places the bracket and fires [onTradeLevelBracketActivated] with the chosen price
     * so your order form can populate the SL/TP input field.
     * @param bracketType `"sl"` or `"tp"`.
     */
    fun addLevelBracket(label: String, bracketType: String) =
        sendCommand(BridgeCommand.AddLevelBracket(label, bracketType))

    /**
     * Unified bracket placement — works for both existing levels and the active draft order.
     * Pass [label] (OrderID/TradeID) for an existing level; omit it for the active draft order.
     * Fires [onTradeLevelBracketActivated] with the auto-computed price.
     * The event's label is null when the bracket was placed on a draft order.
     * @param bracketType `"sl"` or `"tp"`.
     */
    fun addBracket(bracketType: String, label: String? = null) =
        sendCommand(BridgeCommand.AddBracket(bracketType, label))

    /**
     * Unified bracket removal — works for both existing levels and the active draft order.
     * Pass [label] (OrderID/TradeID) for an existing level; omit it for the active draft order.
     * @param bracketType `"sl"` or `"tp"`.
     */
    fun removeBracket(bracketType: String, label: String? = null) =
        sendCommand(BridgeCommand.RemoveBracket(bracketType, label))

    /** Cancels an in-progress level edit, reverting to the last confirmed price. */
    fun cancelLevelEdit(label: String) = sendCommand(BridgeCommand.CancelLevelEdit(label))

    /** Programmatically selects (highlights) a level, or deselects all when [label] is null. */
    fun selectLevel(label: String?) = sendCommand(BridgeCommand.SelectLevel(label))

    // ── Draft orders ──────────────────────────────────────────────────────────

    /**
     * Shows a draggable limit or stop draft order line on the chart.
     * While the user drags it, [onTradeLevelDrag] events fire; confirming emits [onTradeLevelConfirmed].
     * @param side `"buy"` or `"sell"`.
     * @param orderType `"limit"` or `"stop"`.
     */
    fun showDraftOrder(price: Double, side: String, orderType: String) =
        sendCommand(BridgeCommand.ShowDraftOrder(price, side, orderType))

    /**
     * Shows a non-draggable market-order preview line.
     * SL/TP brackets can still be attached via [updateDraftOrderBracket].
     * @param side `"buy"` or `"sell"`.
     */
    fun showMarketDraft(price: Double, side: String) =
        sendCommand(BridgeCommand.ShowMarketDraft(price, side))

    /** Removes any active draft order from the chart. */
    fun clearDraftOrder() = sendCommand(BridgeCommand.ClearDraftOrder)

    /** Cancels whatever is currently being edited or drafted on the chart (draft order or level edit). No-op when nothing is active. */
    fun cancelCurrentEdit() = sendCommand(BridgeCommand.CancelCurrentEdit)

    /** Updates the lot quantity shown on the active draft order chip. */
    fun setDraftOrderLots(lots: Double) = sendCommand(BridgeCommand.SetDraftOrderLots(lots))

    /** Moves the draft order price line to a new price. */
    fun updateDraftOrderPrice(price: Double) = sendCommand(BridgeCommand.UpdateDraftOrderPrice(price))

    /**
     * Updates or removes a SL/TP bracket on the active draft order.
     * @param bracketType `"sl"` or `"tp"`.
     * @param price Pass `null` to remove the bracket.
     */
    fun updateDraftOrderBracket(bracketType: String, price: Double?) =
        sendCommand(BridgeCommand.UpdateDraftOrderBracket(bracketType, price))

    /**
     * Sets or clears the estimated PNL text shown on a draft order's SL or TP bracket line.
     * Call this after [updateDraftOrderBracket] to display your consumer-calculated P&L estimate.
     * @param bracketType `"sl"` or `"tp"`.
     * @param pnlText Pre-formatted string (e.g. `"-$12.50"`). Pass `null` to clear.
     */
    fun setDraftBracketPnl(bracketType: String, pnlText: String?) =
        sendCommand(BridgeCommand.SetDraftBracketPnl(bracketType, pnlText))

    // ── UI controls ───────────────────────────────────────────────────────────

    /** Shows or hides the volume sub-pane. */
    fun setVolume(show: Boolean) = sendCommand(BridgeCommand.SetVolume(show))

    /** Toggles TFC (Trade from Charts) on or off at runtime. Only effective when `tfcEnabled` was `true` at init. */
    fun setTfcActive(enabled: Boolean) = sendCommand(BridgeCommand.SetTfcActive(enabled))

    /** Updates the symbol list used by the ISIN picker modal after initial setup. */
    fun setIsins(isins: List<String>) = sendCommand(BridgeCommand.SetIsins(isins))

    /** Resets both price and time axes to their default auto-fit state. */
    fun resetView() = sendCommand(BridgeCommand.ResetView)

    /**
     * Completely resets the chart to a blank state.
     *
     * Cancels any in-flight data fetch, clears all bars, and discards the live
     * bid/ask price line.  Call this before switching to a new symbol so that no
     * previous symbol data bleeds into the new chart, then follow with [loadData].
     *
     * ```kotlin
     * chart.setSymbol("GBPUSD").resetData()
     * // … fetch new bars …
     * chart.loadData(newBars)
     * ```
     */
    fun resetData() = sendCommand(BridgeCommand.ResetData)

    /** Shows or hides the loading overlay. */
    fun setLoading(loading: Boolean) = sendCommand(BridgeCommand.SetLoading(loading))

    /**
     * Updates per-theme deep-partial color overrides and rebuilds the active theme.
     * @param overridesJson Raw JSON string, e.g. `{"dark":{"background":"#111"},"light":{"background":"#fff"}}`.
     */
    fun setThemeOverrides(overridesJson: String) = sendCommand(BridgeCommand.SetThemeOverrides(overridesJson))

    /** Updates per-theme deep-partial color overrides using typed [ThemeOverrides]. */
    fun setThemeOverrides(overrides: ThemeOverrides) = sendCommand(BridgeCommand.SetThemeOverrides(overrides.toJsonString()))

    /**
     * Recolours the **canvas only** at runtime: `background`, `grid`, `axisText`,
     * `axisBorder`, `crosshair` repaint the plot and its axes, while the chrome (header,
     * bottom bar, drawing toolbar, dialogs, popovers) keeps the theme from [setThemeOverrides].
     * Use this — not `setThemeOverrides(ThemeOverrides(dark = ChartThemeOverride(background = …)))`,
     * which by design paints the whole chart — for a chart background that must stay inside
     * the plot. Same per-theme picks as the in-chart Chart Settings dialog; persisted in the
     * state snapshot.
     * @param colorsJson Raw JSON string, e.g. `{"dark":{"background":"#ff00ff"}}`; `null` clears the picks.
     */
    fun setCanvasColors(colorsJson: String?) = sendCommand(BridgeCommand.SetCanvasColors(colorsJson))

    /** Recolours the canvas only using typed [CanvasColors]. */
    fun setCanvasColors(colors: CanvasColors) = sendCommand(BridgeCommand.SetCanvasColors(colors.toJsonString()))

    /**
     * Replaces a specific bar with authoritative OHLCV data (e.g. a correction from the server).
     * @param barTime Unix millisecond timestamp of the bar to replace.
     */
    fun correctBar(barTime: Long, bar: OHLCVBar) = sendCommand(BridgeCommand.CorrectBar(barTime, bar))

    // ── Internal ──────────────────────────────────────────────────────────────

    /**
     * Serialises [cmd] and either queues it (if the chart is not yet ready) or
     * evaluates it in the WebView immediately. Safe to call from any thread.
     */
    private fun sendCommand(cmd: BridgeCommand) {
        if (cmd is BridgeCommand.Init) userInitCalled = true
        val json = cmd.toJson()
        synchronized(this) {
            if (!isReady) {
                commandQueue.add(json)
                return
            }
        }
        evalOnMainThread(json)
    }

    private fun evalOnMainThread(json: String) {
        val escaped = json.replace("\\", "\\\\").replace("'", "\\'")
        webView.post { webView.evaluateJavascript("window.ChartBridge.send('$escaped');", null) }
    }

    /**
     * Evaluates multiple commands in a single [WebView.evaluateJavascript] call so they run
     * atomically in JS with no rendered frame between them.
     */
    private fun evalBatch(cmds: List<String>) {
        val js = cmds.joinToString(";") { json ->
            "window.ChartBridge.send('${json.replace("\\", "\\\\").replace("'", "\\'")}')"
        }
        webView.post { webView.evaluateJavascript("$js;", null) }
    }

    /**
     * Flushes all queued commands as a single [WebView.evaluateJavascript] call.
     * Must be called on the main thread (i.e. from [dispatchEvent] on [BridgeEvent.Ready]).
     */
    private fun flushCommandQueue() {
        val batch = synchronized(this) {
            isReady = true
            commandQueue.toList().also { commandQueue.clear() }
        }
        if (batch.isEmpty()) return
        val js = batch.joinToString(";") { json ->
            "window.ChartBridge.send('${json.replace("\\", "\\\\").replace("'", "\\'")}')"
        }
        webView.evaluateJavascript("$js;", null)
    }
}
