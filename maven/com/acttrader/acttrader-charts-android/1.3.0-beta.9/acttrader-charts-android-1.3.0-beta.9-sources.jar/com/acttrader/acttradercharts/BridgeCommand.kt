package com.acttrader.acttradercharts

import android.util.Log
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

private const val TAG = "ActtraderCharts"

private fun JSONObject.putJson(key: String, json: String) {
    try {
        put(key, JSONObject(json))
    } catch (e: JSONException) {
        Log.w(TAG, "Dropping malformed JSON for key '$key': ${e.message}")
    }
}

/**
 * Cross-pane sync toggles for the chart-owned layout popover (Symbol / Interval
 * / Crosshair / Time / Date range). All fields are nullable — a `null` field is
 * omitted from the payload and keeps its current (or library-default) value on
 * the chart side. Only meaningful when `enableMultipleLayouts = true`.
 */
data class LayoutSync(
    val symbol: Boolean? = null,
    val interval: Boolean? = null,
    val crosshair: Boolean? = null,
    val time: Boolean? = null,
    val dateRange: Boolean? = null,
) {
    fun toJson(): JSONObject = JSONObject().apply {
        symbol?.let { put("symbol", it) }
        interval?.let { put("interval", it) }
        crosshair?.let { put("crosshair", it) }
        time?.let { put("time", it) }
        dateRange?.let { put("dateRange", it) }
    }
}

/**
 * Commands sent from native Android code to the chart WebView.
 * Each subclass serialises itself to the JSON format expected by `window.ChartBridge.send()`.
 *
 * Protocol shape: `{ "type": "<cmd>", "payload": { ...fields } }`
 */
sealed class BridgeCommand {

    abstract fun toJson(): String

    // ── Core ──────────────────────────────────────────────────────────────────

    /** Re-creates the chart engine. Sent once after the WebView finishes loading. */
    data class Init(
        val theme: String = "dark",
        val symbol: String? = null,
        val series: String? = null,
        val timeframe: String? = null,
        val duration: String? = null,
        val enableTrading: Boolean = false,
        val showVolume: Boolean? = null,
        val showUI: Boolean? = null,
        val showDrawingTools: Boolean? = null,
        val showBidAskLines: Boolean? = null,
        /** Show the Ask price line independently. `null` falls back to the
         *  legacy [showBidAskLines] behavior. */
        val showAskLine: Boolean? = null,
        /** Show the Bid price line independently. `null` falls back to the
         *  legacy [showBidAskLines] behavior. */
        val showBidLine: Boolean? = null,
        val showActLogo: Boolean? = null,
        val showCandleCountdown: Boolean? = null,
        val candleCountdownTimeframes: List<String>? = null,
        val disableCountdownOnMobile: Boolean? = null,
        val maxSubPanes: Int? = null,
        val mobileBarDivisor: Int? = null,
        /**
         * Minimum bars expected from the initial fetch before giving up. When the
         * native loader returns fewer bars, the chart engine automatically widens
         * the lookback window and retries — handles weekends, market closures, and
         * sparse instruments gracefully. Default: `10`.
         */
        val minInitialBars: Int? = null,
        /**
         * Hard ceiling (in milliseconds) on fetch-window lookback for auto-widening
         * retries. Default: `365L * 24 * 60 * 60 * 1000` (365 days).
         */
        val maxLookbackMs: Long? = null,
        /** Enable momentum (kinetic) scrolling on drag release. Default: `true`. */
        val momentumScrollEnabled: Boolean? = null,
        /** Per-frame velocity decay factor for momentum, normalised to 60 fps. Clamped [0.80, 0.99]. Default: `0.95`. */
        val momentumDecay: Double? = null,
        /** Minimum release velocity (px/ms) to trigger momentum. Default: `0.3`. */
        val momentumThreshold: Double? = null,
        /** Maximum launch velocity (px/ms) for momentum. Default: `6.0`. */
        val momentumMaxVelocity: Double? = null,
        val targetCandleWidth: Double? = null,
        /** Which price drives live candle close/high/low: `"bid"` (default), `"ask"`,
         *  or `"ltp"` — build candles from the last traded price (exchange/dealing
         *  feeds); ticks without a valid LTP fall back to the bid. */
        val tickClosePriceSource: String? = null,
        /** Show the LTP marker (dashed price line + axis tag). `null` (default):
         *  shown only in `"ltp"` mode. `true`: always shown when the feed supplies
         *  an LTP. `false`: hidden even in `"ltp"` mode. */
        val showLtpPrice: Boolean? = null,
        val tradesThresholdForHorizontalLine: Int? = null,
        val tradeDisplayFilter: String? = null,
        val positionRenderStyle: String? = null,
        val hideLevelConfirmCancel: Boolean? = null,
        /**
         * When `true`, clicking or tapping outside a selected/active trade level dismisses
         * it (reverting any pending edits, mirroring ✗ Cancel). When `false` (default), the
         * active level is preserved across outside clicks — only ✓ / ✗ buttons, tapping the
         * level itself, or removing it via `setLevels` will dismiss it. Recommended `false`
         * so incidental clicks (price-axis resize, taps outside the QTY input) don't drop
         * an in-progress edit. Default: `false`.
         */
        val deselectActiveOnOutsideClick: Boolean? = null,
        /**
         * Always render SL/TP bracket lines + price pills, even when the parent
         * trade level is not hovered/selected. Close (×) buttons remain hover-only.
         * Default: `true`. Set `false` to only show them on hover/selection.
         */
        val showTradeLevelsAlways: Boolean? = true,
        /**
         * Show the candle countdown timer on the right price axis, just below the
         * live price tag. Subject to the same `candleCountdownTimeframes` filter.
         * Default: `false`.
         */
        val showPriceAxisCountdown: Boolean? = null,
        /**
         * Multiplier for trade-level Confirm/Cancel/Edit/Close button radii and gaps.
         * Scales visuals AND hit/drag areas together — useful for touch targets.
         * Clamped to `[1.0, 3.0]`. Default: `1.0`.
         */
        val tradeLevelButtonScale: Double? = null,
        /** `"price"` (default) or `"amount"` — what the SL/TP bracket pills show. */
        val bracketLabelMode: String? = null,
        /** Currency symbol for SL/TP amounts when `bracketLabelMode = "amount"`. Default `"$"`. */
        val currencySymbol: String? = null,
        val levelClusteringEnabled: Boolean? = null,
        val clusterThresholdDistance: Int? = null,
        /** Enable TFC toggle button in the top bar. When `false`, TFC is completely disabled. Default: `true`. */
        val tfcEnabled: Boolean? = null,
        val showSettings: Boolean? = null,
        /** Show the fullscreen toggle button in the top bar. Default: `false` on mobile (hidden). */
        val showFullscreenButton: Boolean = false,
        val hideSymbolAndTick: Boolean? = null,
        val hideOHLCV: Boolean? = null,
        val showBottomBar: Boolean? = null,
        /** Per-timeframe base interval override for client-side aggregation, e.g. `mapOf("1h" to "30m")`. */
        val aggregateFrom: Map<String, String>? = null,
        /** Per-theme canvas background color overrides as a raw JSON string. */
        val canvasColorsJson: String? = null,
        /** Per-theme deep-partial color overrides for the built-in themes as a raw JSON string. */
        val themeOverridesJson: String? = null,
        /** User-visible string overrides for i18n/localisation as a raw JSON string. */
        val labelsJson: String? = null,
        /** Per-component UI configuration overrides as a raw JSON string. */
        val uiConfigJson: String? = null,
        /** Override the default duration → timeframe pairings, e.g. `mapOf("1Y" to "1D")`. */
        val durationTimeframeMap: Map<String, String>? = null,
        /** When true, fires a `symbolClick` bridge event on symbol tap instead of opening the picker modal. */
        val onSymbolClick: Boolean = false,
        /**
         * When true, the `"mobile"` header renders an "Ask AI" (✦) button that fires
         * a [BridgeEvent.AskAiClick] event on tap. No effect in other header layouts.
         * Default: `false` (button hidden).
         */
        val onAskAiClick: Boolean = false,
        /** IANA timezone string for time-axis and crosshair labels. Default: `"UTC"`. */
        val timezone: String? = null,
        /**
         * Top-bar variant. `"simple"` (default) shows the classic TopBar; `"advanced"`
         * uses the compact pill-style AdvancedToolbar; `"compact"` uses the slim
         * per-pane CompactToolbar — recommended only when this chart is one cell
         * of a host-rendered multi-pane grid; `"mobile"` renders the compact mobile
         * header (Tools button · timeframe pills · optional Ask AI button) — gate it
         * yourself, e.g. `headerLayout = if (isMobile) "mobile" else null`.
         */
        val headerLayout: String? = null,
        /**
         * Enables the chart-owned multi-layout popover (Layout button + 26 preset
         * picker + sync toggles). Fires `layoutChange` events; host is responsible
         * for actually mounting N panes.
         */
        val enableMultipleLayouts: Boolean? = null,
        /**
         * Enables the chart-owned snapshot popover (Snapshot button + Download/Copy).
         * Fires `snapshot` events with the PNG data URL; native layers can intercept
         * to save via platform APIs.
         */
        val enableSnapshot: Boolean? = null,
        /**
         * Hides the chart header entirely (whichever variant [headerLayout] would
         * have rendered). Bottom bar, drawing tools, and on-canvas overlays stay on
         * their own flags. Drive the chart from native UI via [BridgeCommand.SetTimeframe],
         * [BridgeCommand.SetSeries], [BridgeCommand.AddIndicatorByName],
         * [BridgeCommand.RemoveIndicator]. Default: `false` (header visible).
         */
        val hideHeader: Boolean? = null,
        /**
         * Compare symbols to add automatically on chart init. Each entry triggers
         * a [BridgeEvent.CompareDataRequest] against the initial primary range —
         * respond via [BridgeCommand.ResolveCompareDataRequest].
         */
        val initialCompares: List<String>? = null,
        /** Maximum concurrent compare symbols. Adding beyond emits [BridgeEvent.CompareError]. Default: `8`. */
        val maxCompares: Int? = null,
        /**
         * Initial state of the chart-owned layout popover's cross-pane sync
         * toggles (only meaningful with [enableMultipleLayouts]). Partial — any
         * `null` field falls back to the library default. Change it later on a
         * live chart via [ActtraderChartsView.setLayoutSync].
         */
        val layoutSync: LayoutSync? = null,
    ) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "init")
            put("payload", JSONObject().apply {
                put("theme", theme)
                symbol?.let { put("symbol", it) }
                series?.let { put("series", it) }
                timeframe?.let { put("timeframe", it) }
                duration?.let { put("duration", it) }
                if (enableTrading) {
                    put("enableTrading", true)
                }
                showVolume?.let { put("showVolume", it) }
                showUI?.let { put("showUI", it) }
                showDrawingTools?.let { put("showDrawingTools", it) }
                showBidAskLines?.let { put("showBidAskLines", it) }
                showAskLine?.let { put("showAskLine", it) }
                showBidLine?.let { put("showBidLine", it) }
                showActLogo?.let { put("showActLogo", it) }
                showCandleCountdown?.let { put("showCandleCountdown", it) }
                candleCountdownTimeframes?.let { put("candleCountdownTimeframes", JSONArray(it)) }
                disableCountdownOnMobile?.let { put("disableCountdownOnMobile", it) }
                maxSubPanes?.let { put("maxSubPanes", it) }
                mobileBarDivisor?.let { put("mobileBarDivisor", it) }
                minInitialBars?.let { put("minInitialBars", it) }
                maxLookbackMs?.let { put("maxLookbackMs", it) }
                momentumScrollEnabled?.let { put("momentumScrollEnabled", it) }
                momentumDecay?.let { put("momentumDecay", it) }
                momentumThreshold?.let { put("momentumThreshold", it) }
                momentumMaxVelocity?.let { put("momentumMaxVelocity", it) }
                targetCandleWidth?.let { put("targetCandleWidth", it) }
                tickClosePriceSource?.let { put("tickClosePriceSource", it) }
                showLtpPrice?.let { put("showLtpPrice", it) }
                tradesThresholdForHorizontalLine?.let { put("tradesThresholdForHorizontalLine", it) }
                tradeDisplayFilter?.let { put("tradeDisplayFilter", it) }
                positionRenderStyle?.let { put("positionRenderStyle", it) }
                hideLevelConfirmCancel?.let { put("hideLevelConfirmCancel", it) }
                deselectActiveOnOutsideClick?.let { put("deselectActiveOnOutsideClick", it) }
                showTradeLevelsAlways?.let { put("showTradeLevelsAlways", it) }
                showPriceAxisCountdown?.let { put("showPriceAxisCountdown", it) }
                tradeLevelButtonScale?.let { put("tradeLevelButtonScale", it) }
                bracketLabelMode?.let { put("bracketLabelMode", it) }
                currencySymbol?.let { put("currencySymbol", it) }
                levelClusteringEnabled?.let { put("levelClusteringEnabled", it) }
                clusterThresholdDistance?.let { put("clusterThresholdDistance", it) }
                tfcEnabled?.let { put("tfcEnabled", it) }
                showSettings?.let { put("showSettings", it) }
                put("showFullscreenButton", showFullscreenButton)
                hideSymbolAndTick?.let { put("hideSymbolAndTick", it) }
                hideOHLCV?.let { put("hideOHLCV", it) }
                showBottomBar?.let { put("showBottomBar", it) }
                aggregateFrom?.let { put("aggregateFrom", JSONObject(it)) }
                durationTimeframeMap?.let { put("durationTimeframeMap", JSONObject(it)) }
                canvasColorsJson?.let { putJson("canvasColors", it) }
                themeOverridesJson?.let { putJson("themeOverrides", it) }
                labelsJson?.let { putJson("labels", it) }
                uiConfigJson?.let { putJson("uiConfig", it) }
                if (onSymbolClick) put("onSymbolClick", true)
                if (onAskAiClick) put("onAskAiClick", true)
                timezone?.let { put("timezone", it) }
                headerLayout?.let { put("headerLayout", it) }
                enableMultipleLayouts?.let { put("enableMultipleLayouts", it) }
                enableSnapshot?.let { put("enableSnapshot", it) }
                hideHeader?.let { put("hideHeader", it) }
                initialCompares?.let { put("initialCompares", JSONArray(it)) }
                maxCompares?.let { put("maxCompares", it) }
                layoutSync?.let { put("layoutSync", it.toJson()) }
            })
        }.toString()
    }

    /** Replaces the full dataset. */
    data class LoadData(
        val bars: List<OHLCVBar>,
        val fitAll: Boolean = false,
    ) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "loadData")
            put("payload", JSONObject().apply {
                put("bars", JSONArray().also { arr ->
                    bars.forEach { bar ->
                        arr.put(JSONObject().apply {
                            put("open", bar.open)
                            put("high", bar.high)
                            put("low", bar.low)
                            put("close", bar.close)
                            put("volume", bar.volume)
                            put("time", bar.time)
                        })
                    }
                })
                put("fitAll", fitAll)
            })
        }.toString()
    }

    /** Pushes a live tick (bid/ask/timestamp) for streaming updates.
     *  [ltp]/[ltpv] (last traded price/volume) are optional — sent by
     *  exchange/dealing feeds and consumed when `tickClosePriceSource = "ltp"`. */
    data class PushTick(
        val bid: Double,
        val ask: Double,
        val timestamp: Long,
        val ltp: Double? = null,
        val ltpv: Double? = null,
    ) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "pushTick")
            put("payload", JSONObject().apply {
                put("B", bid)
                put("A", ask)
                put("T", timestamp)
                ltp?.let { put("LTP", it) }
                ltpv?.let { put("LTPV", it) }
            })
        }.toString()
    }

    /** Shows/hides the LTP price marker at runtime. Pass `null` to restore the
     *  default (marker follows `tickClosePriceSource = "ltp"`). */
    data class SetShowLtpPrice(val show: Boolean?) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "setShowLtpPrice")
            put("payload", JSONObject().apply { show?.let { put("show", it) } })
        }.toString()
    }

    // ── Appearance ────────────────────────────────────────────────────────────

    /** Switches between `"dark"` and `"light"` themes. */
    data class SetTheme(val theme: String) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "setTheme")
            put("payload", JSONObject().apply {
                put("theme", theme)
            })
        }.toString()
    }

    /**
     * Changes the display timezone for time-axis and crosshair labels.
     * Accepts any IANA string (e.g. `"America/New_York"`), `"UTC"`, or `"local"`.
     */
    data class SetTimezone(val timezone: String) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "setTimezone")
            put("payload", JSONObject().apply {
                put("timezone", timezone)
            })
        }.toString()
    }

    /**
     * Updates the chart-owned layout popover's cross-pane sync toggles. Partial —
     * `null` fields keep their current value. Only meaningful with
     * `enableMultipleLayouts = true`.
     */
    data class SetLayoutSync(val sync: LayoutSync) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "setLayoutSync")
            put("payload", sync.toJson())
        }.toString()
    }

    /** Changes the chart series type (e.g. `"candlestick"`, `"line"`, `"area"`). */
    data class SetSeries(val series: String) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "setSeries")
            put("payload", JSONObject().apply {
                put("series", series)
            })
        }.toString()
    }

    /** Changes the active timeframe (e.g. `"1m"`, `"1h"`, `"1D"`). */
    /**
     * Selects a duration and refetches. The timeframe is paired from
     * `durationTimeframeMap` unless [timeframe] is given, and the x-axis
     * rescales from the new bars — no reinitialisation needed.
     */
    data class SetDuration(val duration: String, val timeframe: String? = null) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "setDuration")
            put("payload", JSONObject().apply {
                put("duration", duration)
                timeframe?.let { put("timeframe", it) }
            })
        }.toString()
    }

    /** Switches SL/TP pills between the bracket price and the money it is worth. */
    data class SetBracketLabelMode(val mode: String, val currencySymbol: String? = null) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "setBracketLabelMode")
            put("payload", JSONObject().apply {
                put("mode", mode)
                currencySymbol?.let { put("currencySymbol", it) }
            })
        }.toString()
    }

    data class SetTimeframe(val timeframe: String) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "setTimeframe")
            put("payload", JSONObject().apply {
                put("timeframe", timeframe)
            })
        }.toString()
    }

    /** Updates the displayed symbol name. */
    data class SetSymbol(val symbol: String) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "setSymbol")
            put("payload", JSONObject().apply {
                put("symbol", symbol)
            })
        }.toString()
    }

    // ── Studies / Drawings ────────────────────────────────────────────────────

    /**
     * Adds a study overlay or oscillator by short name (e.g. `"SMA"`, `"RSI"`).
     * @param params Optional key-value parameters (e.g. `mapOf("period" to 20)`).
     */
    data class AddIndicator(
        val name: String,
        val params: Map<String, Any>? = null,
    ) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "addIndicator")
            put("payload", JSONObject().apply {
                put("shortName", name)
                params?.let { put("params", JSONObject(it)) }
            })
        }.toString()
    }

    /** Removes a study by name. */
    data class RemoveIndicator(val name: String) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "removeIndicator")
            put("payload", JSONObject().apply {
                put("name", name)
            })
        }.toString()
    }

    /** Activates a drawing tool by ID, or passes `null` to deactivate. */
    data class SetDrawingTool(val tool: String?) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "setDrawingTool")
            put("payload", JSONObject().apply {
                if (tool != null) put("tool", tool) else put("tool", JSONObject.NULL)
            })
        }.toString()
    }

    /** Removes all drawings from the chart. */
    object ClearAllDrawings : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "clearAllDrawings")
            put("payload", JSONObject())
        }.toString()
    }

    // ── State ─────────────────────────────────────────────────────────────────

    /** Requests the current chart state; fires a `stateSnapshot` event in response. */
    object GetState : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "getState")
            put("payload", JSONObject())
        }.toString()
    }

    /**
     * Restores a previously captured chart state.
     * @param stateJson Raw JSON string returned by a prior `stateSnapshot` event.
     */
    data class SetState(val stateJson: String) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "setState")
            put("payload", JSONObject(stateJson))
        }.toString()
    }

    /**
     * Resolves a pending dataLoader request with fetched bars.
     * @param requestId The ID received in the `dataRequest` bridge event.
     * @param bars The fetched OHLCV bars to return to the chart engine.
     */
    data class ResolveDataRequest(
        val requestId: String,
        val bars: List<OHLCVBar>,
    ) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "resolveDataRequest")
            put("payload", JSONObject().apply {
                put("requestId", requestId)
                put("bars", JSONArray().also { arr ->
                    bars.forEach { bar ->
                        arr.put(JSONObject().apply {
                            put("open", bar.open)
                            put("high", bar.high)
                            put("low", bar.low)
                            put("close", bar.close)
                            put("volume", bar.volume)
                            put("time", bar.time)
                        })
                    }
                })
            })
        }.toString()
    }

    /** Enables or disables verbose tick/render logging in the chart engine. */
    data class SetDebug(val enabled: Boolean) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "setDebug")
            put("payload", JSONObject().apply {
                put("enabled", enabled)
            })
        }.toString()
    }

    /** Destroys the chart engine and releases resources. */
    object Destroy : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "destroy")
            put("payload", JSONObject())
        }.toString()
    }

    // ── Trade levels ──────────────────────────────────────────────────────────

    /**
     * Replaces all levels of the given [type] with [levels].
     * Each map must contain at least [labelKey] and [priceKey] entries.
     * Optional fields per entry: `side`, `stopLossPrice`, `takeProfitPrice`,
     * `pnl`, `pnlText`, `text`, `lots`, `orderType`, `entryPriceEditable`.
     * @param type `"position"`, `"pending"`, or `"trade"`.
     */
    data class SetLevels(
        val levels: List<Map<String, Any>>,
        val labelKey: String,
        val priceKey: String,
        val type: String,
        val pnlKey: String? = null,
        val pnlTextKey: String? = null,
    ) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "setLevels")
            put("payload", JSONObject().apply {
                put("levels", JSONArray().also { arr ->
                    levels.forEach { arr.put(JSONObject(it)) }
                })
                put("labelKey", labelKey)
                put("priceKey", priceKey)
                put("type", type)
                pnlKey?.let { put("pnlKey", it) }
                pnlTextKey?.let { put("pnlTextKey", it) }
            })
        }.toString()
    }

    /** Removes a single level by its label. No-op if not found. */
    data class RemoveLevelByLabel(val label: String) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "removeLevelByLabel")
            put("payload", JSONObject().apply { put("label", label) })
        }.toString()
    }

    /** Updates the entry price of an existing level. */
    /**
     * Mirrors a quantity change made in the host's own modify panel onto the
     * level's pill. Staged like a chart-side qty edit, so it survives `setLevels`
     * refreshes and is reverted by `cancelCurrentEdit`.
     */
    data class UpdateLevelQty(val label: String, val qty: Double) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "updateLevelQty")
            put("payload", JSONObject().apply {
                put("label", label)
                put("qty", qty)
            })
        }.toString()
    }

    data class UpdateLevelMainPrice(val label: String, val price: Double) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "updateLevelMainPrice")
            put("payload", JSONObject().apply {
                put("label", label)
                put("price", price)
            })
        }.toString()
    }

    /**
     * Updates or removes a SL/TP bracket on an existing level.
     * @param bracketType `"sl"` or `"tp"`.
     * @param price Pass `null` to remove the bracket.
     */
    data class UpdateLevelBracket(
        val label: String,
        val bracketType: String,
        val price: Double?,
    ) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "updateLevelBracket")
            put("payload", JSONObject().apply {
                put("label", label)
                put("bracketType", bracketType.lowercase())
                put("price", if (price != null) price else JSONObject.NULL)
            })
        }.toString()
    }

    /**
     * Adds a SL or TP bracket to an existing level at an auto-computed default price.
     * Listen for [BridgeEvent.TradeLevelBracketActivated] to receive the chosen price.
     * @param bracketType `"sl"` or `"tp"`.
     */
    data class AddLevelBracket(
        val label: String,
        val bracketType: String,
    ) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "addLevelBracket")
            put("payload", JSONObject().apply {
                put("label", label)
                put("bracketType", bracketType.lowercase())
            })
        }.toString()
    }

    /**
     * Unified bracket placement — works for both existing levels and the active draft order.
     * Pass [label] (OrderID/TradeID) for an existing level; omit it (null) for the active draft order.
     * Fires [BridgeEvent.TradeLevelBracketActivated] with the auto-computed price.
     * The event's label is null when the bracket was placed on a draft order.
     * @param bracketType `"sl"` or `"tp"`.
     */
    data class AddBracket(
        val bracketType: String,
        val label: String? = null,
    ) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "addBracket")
            put("payload", JSONObject().apply {
                put("bracketType", bracketType.lowercase())
                if (label != null) put("label", label)
            })
        }.toString()
    }

    /**
     * Unified bracket removal — works for both existing levels and the active draft order.
     * Pass [label] (OrderID/TradeID) for an existing level; omit it (null) for the active draft order.
     * @param bracketType `"sl"` or `"tp"`.
     */
    data class RemoveBracket(
        val bracketType: String,
        val label: String? = null,
    ) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "removeBracket")
            put("payload", JSONObject().apply {
                put("bracketType", bracketType.lowercase())
                if (label != null) put("label", label)
            })
        }.toString()
    }

    /** Cancels an in-progress level edit, reverting to the last confirmed price. */
    data class CancelLevelEdit(val label: String) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "cancelLevelEdit")
            put("payload", JSONObject().apply { put("label", label) })
        }.toString()
    }

    /** Programmatically selects a level, or deselects all when [label] is null. */
    data class SelectLevel(val label: String?) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "selectLevel")
            put("payload", JSONObject().apply {
                put("label", if (label != null) label else JSONObject.NULL)
            })
        }.toString()
    }

    // ── Draft orders ──────────────────────────────────────────────────────────

    /**
     * Shows a draggable limit or stop draft order line on the chart.
     * While the user drags it, `tradeLevelDrag` events fire; confirming emits `tradeLevelConfirmed`.
     * @param side `"buy"` or `"sell"`.
     * @param orderType `"limit"` or `"stop"`.
     */
    data class ShowDraftOrder(
        val price: Double,
        val side: String,
        val orderType: String,
    ) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "showDraftOrder")
            put("payload", JSONObject().apply {
                put("price", price)
                put("side", side)
                put("orderType", orderType)
            })
        }.toString()
    }

    /**
     * Shows a non-draggable market-order preview line.
     * SL/TP brackets can be attached via [UpdateDraftOrderBracket].
     * @param side `"buy"` or `"sell"`.
     */
    data class ShowMarketDraft(val price: Double, val side: String) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "showMarketDraft")
            put("payload", JSONObject().apply {
                put("price", price)
                put("side", side)
            })
        }.toString()
    }

    /** Removes any active draft order from the chart. */
    object ClearDraftOrder : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "clearDraftOrder")
            put("payload", JSONObject())
        }.toString()
    }

    /** Cancels whatever is currently being edited or drafted on the chart (draft order or level edit). */
    object CancelCurrentEdit : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "cancelCurrentEdit")
            put("payload", JSONObject())
        }.toString()
    }

    /** Updates the lot quantity shown on the active draft order chip. */
    data class SetDraftOrderLots(val lots: Double) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "setDraftOrderLots")
            put("payload", JSONObject().apply { put("lots", lots) })
        }.toString()
    }

    /** Moves the draft order price line to a new price. */
    data class UpdateDraftOrderPrice(val price: Double) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "updateDraftOrderPrice")
            put("payload", JSONObject().apply { put("price", price) })
        }.toString()
    }

    /**
     * Updates or removes a SL/TP bracket on the active draft order.
     * @param bracketType `"sl"` or `"tp"`.
     * @param price Pass `null` to remove the bracket.
     */
    data class UpdateDraftOrderBracket(val bracketType: String, val price: Double?) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "updateDraftOrderBracket")
            put("payload", JSONObject().apply {
                put("bracketType", bracketType.lowercase())
                put("price", if (price != null) price else JSONObject.NULL)
            })
        }.toString()
    }

    /**
     * Sets or clears the estimated PNL text shown on a draft order's SL or TP bracket line.
     * Pass `null` for [pnlText] to clear.
     * @param bracketType `"sl"` or `"tp"`.
     */
    data class SetDraftBracketPnl(val bracketType: String, val pnlText: String?) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "setDraftBracketPnl")
            put("payload", JSONObject().apply {
                put("bracketType", bracketType.lowercase())
                put("pnlText", if (pnlText != null) pnlText else JSONObject.NULL)
            })
        }.toString()
    }

    // ── UI controls ───────────────────────────────────────────────────────────

    /** Shows or hides the volume sub-pane. */
    data class SetVolume(val show: Boolean) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "setVolume")
            put("payload", JSONObject().apply { put("show", show) })
        }.toString()
    }

    /** Toggles TFC (Trade from Charts) on or off at runtime. */
    data class SetTfcActive(val enabled: Boolean) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "setTfcActive")
            put("payload", JSONObject().apply { put("enabled", enabled) })
        }.toString()
    }

    /** Updates the symbol list used by the ISIN picker modal after initial setup. */
    data class SetIsins(val isins: List<String>) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "setIsins")
            put("payload", JSONObject().apply { put("isins", JSONArray(isins)) })
        }.toString()
    }

    /** Resets both price and time axes to their default auto-fit state. */
    object ResetView : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "resetView")
            put("payload", JSONObject())
        }.toString()
    }

    /**
     * Dismisses any open flyouts, modals, dropdowns, or popovers in the chart UI.
     * Intended for wiring the Android hardware back button.
     *
     * Prefer calling [ActtraderChartsView.dismissAllUI], which short-circuits the
     * WebView round-trip when nothing is open and returns a boolean so you can
     * decide whether to consume the back event.
     */
    object DismissAllUI : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "dismissAllUI")
            put("payload", JSONObject())
        }.toString()
    }

    /**
     * Completely resets the chart to a blank state — clears all bars, the live
     * price line, and any in-flight fetch.  Call this before switching to a new
     * symbol so that no previous symbol data bleeds into the new chart.
     */
    object ResetData : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "resetData")
            put("payload", JSONObject())
        }.toString()
    }

    /** Shows or hides the loading overlay. */
    data class SetLoading(val loading: Boolean) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "setLoading")
            put("payload", JSONObject().apply { put("loading", loading) })
        }.toString()
    }

    /**
     * Updates per-theme deep-partial color overrides and rebuilds the active theme.
     * @param overridesJson Raw JSON string, e.g. `{"dark":{"background":"#111"},"light":{"background":"#fff"}}`.
     */
    data class SetThemeOverrides(val overridesJson: String) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "setThemeOverrides")
            put("payload", JSONObject().apply {
                putJson("overrides", overridesJson)
            })
        }.toString()
    }

    /**
     * Replaces a specific bar with authoritative OHLCV data (e.g. a correction from the server).
     * @param barTime Unix millisecond timestamp of the bar to replace.
     */
    data class CorrectBar(val barTime: Long, val bar: OHLCVBar) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "correctBar")
            put("payload", JSONObject().apply {
                put("barTime", barTime)
                put("bar", JSONObject().apply {
                    put("open", bar.open)
                    put("high", bar.high)
                    put("low", bar.low)
                    put("close", bar.close)
                    put("volume", bar.volume)
                    put("time", bar.time)
                })
            })
        }.toString()
    }

    // ── Compare ───────────────────────────────────────────────────────────────

    /**
     * Adds a compare symbol overlay. The chart will fire a
     * [BridgeEvent.CompareDataRequest]; reply via [ResolveCompareDataRequest].
     */
    data class AddCompare(val symbol: String) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "addCompare")
            put("payload", JSONObject().apply { put("symbol", symbol) })
        }.toString()
    }

    /** Removes a compare symbol. No-op when not active. */
    data class RemoveCompare(val symbol: String) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "removeCompare")
            put("payload", JSONObject().apply { put("symbol", symbol) })
        }.toString()
    }

    /** Removes every active compare symbol. */
    object ClearCompares : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "clearCompares")
            put("payload", JSONObject())
        }.toString()
    }

    /**
     * Resolves a pending [BridgeEvent.CompareDataRequest] with fetched bars.
     * @param requestId The ID from the request event.
     * @param bars Historical OHLCV bars covering the requested range.
     */
    data class ResolveCompareDataRequest(
        val requestId: String,
        val bars: List<OHLCVBar>,
    ) : BridgeCommand() {
        override fun toJson(): String = JSONObject().apply {
            put("type", "resolveCompareDataRequest")
            put("payload", JSONObject().apply {
                put("requestId", requestId)
                put("bars", JSONArray().also { arr ->
                    bars.forEach { bar ->
                        arr.put(JSONObject().apply {
                            put("open", bar.open)
                            put("high", bar.high)
                            put("low", bar.low)
                            put("close", bar.close)
                            put("volume", bar.volume)
                            put("time", bar.time)
                        })
                    }
                })
            })
        }.toString()
    }
}
